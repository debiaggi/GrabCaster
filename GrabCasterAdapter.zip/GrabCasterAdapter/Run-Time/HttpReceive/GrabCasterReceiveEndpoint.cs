//---------------------------------------------------------------------
// File: HttpReceiveEndpoint.cs
// 
// Summary: Implementation of an adapter framework sample adapter. 
//
// Sample: HTTP Receive Adapter, demonstrating request-response and 
//           isolated receiver
//
//
//---------------------------------------------------------------------
// This file is part of the Microsoft BizTalk Server SDK
//
// Copyright (c) Microsoft Corporation. All rights reserved.
//
// This source code is intended only as a supplement to Microsoft BizTalk
// Server release and/or on-line documentation. See these other
// materials for detailed information regarding Microsoft code samples.
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
// KIND, WHETHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
// PURPOSE.
//---------------------------------------------------------------------

namespace Microsoft.Samples.BizTalk.Adapters.GrabCasterReceive
{
    using System.Diagnostics;

    using Microsoft.BizTalk.Component.Interop;
    using Microsoft.BizTalk.TransportProxy.Interop;
    using Microsoft.Samples.BizTalk.Adapter.Common;

    /// <summary>
    /// Summary description for HttpReceiveEndpoint.
    /// </summary>
    public class GrabCasterReceiveEndpoint : ReceiverEndpoint
    {
        private GrabCasterReceiveProperties    properties        = null;
        private string url;

        public GrabCasterReceiveEndpoint()
        {
        }

        public override void Open(string uri, IPropertyBag config, IPropertyBag bizTalkConfig, IPropertyBag handlerPropertyBag, IBTTransportProxy transportProxy, string transportType, string propertyNamespace, ControlledTermination control)
        {
            this.url = uri;
            Trace.WriteLine(string.Format("GrabCasterReceiveEndpoint( uri:{0} ) called", this.url), "HttpReceive: Info");

            this.properties = new GrabCasterReceiveProperties(this.url);
            this.properties.LocationConfiguration(config, bizTalkConfig);
        }

        public override void Update(IPropertyBag config, IPropertyBag bizTalkConfig, IPropertyBag handlerPropertyBag)
        {
            Trace.WriteLine(string.Format("GrabCasterReceiveEndpoint.Update( uri:{0} ) called", this.url), "HttpReceive: Info" );

            // Read the new configuration...
            GrabCasterReceiveProperties newProps = new GrabCasterReceiveProperties(this.url);
            newProps.LocationConfiguration(config, bizTalkConfig);

            // Update the configuration...
            this.properties = newProps;
        }

        public GrabCasterReceiveProperties Configuration
        { 
            get { return this.properties; }
        }
    }
}
