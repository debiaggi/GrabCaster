//---------------------------------------------------------------------
// File: HttpReceive.cs
// 
// Summary: Implementation of an adapter framework sample adapter. 
//
// Sample: HTTP Receive Adapter, demonstrating request-response and 
//           isolated receiver
//
//
//---------------------------------------------------------------------
// This file is part of the Microsoft BizTalk Server SDK
//
// Copyright (c) Microsoft Corporation. All rights reserved.
//
// This source code is intended only as a supplement to Microsoft BizTalk
// Server release and/or on-line documentation. See these other
// materials for detailed information regarding Microsoft code samples.
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
// KIND, WHETHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
// PURPOSE.
//---------------------------------------------------------------------

namespace Microsoft.Samples.BizTalk.Adapters.GrabCasterReceive
{
    using System;
    using System.Diagnostics;
    using System.IO;
    using System.Web;

    using Microsoft.BizTalk.Message.Interop;
    using Microsoft.BizTalk.Streaming;
    using Microsoft.BizTalk.TransportProxy.Interop;
    using Microsoft.Samples.BizTalk.Adapter.Common;


    /// <summary>
    /// Main class for HTTP receive adapters. It provides the implementations of
    /// core interfaces needed to comply with receiver adapter contract.
    /// (1) This class is actually a Singleton. That is there will only ever be one
    /// instance of it created however many locations of this type are actually defined.
    /// (2) Individual locations are identified by a URI and are associated with HttpReceiveEndpoint
    /// (3) It is legal to have messages from different locations submitted in a single
    /// batch and this may be an important optimization. And this is fundamentally why
    /// the Receiver is a singleton.
    /// </summary>
    sealed public class GrabCasterAdapter : Receiver

    {
        private IBTTransportProxy        transportProxy            = null;
        private IBaseMessageFactory msgFactory = null;

        private const string                    protocol                = "GC.NET";
        private const string description = "GrabCaster Receive Adapter";
        private static readonly Guid clsid = new Guid("883C611E-1505-4c55-96D7-E0F5ABF7E62C");
        private ControlledTermination    terminator                = new ControlledTermination();
        private const int                IO_BUFFER_SIZE = 8192;  // 8K
        private bool adapterRegistered = false;

        public GrabCasterAdapter()
            : base(protocol, "1.0", description, protocol, clsid, null, typeof(GrabCasterReceiveEndpoint))
        {
            // Since we are an Isolated Adapter, we need to create
            // this Adapters Transport Proxy and initialize it with
            // one of our urls...
            this.transportProxy = (IBTTransportProxy)new BTTransportProxy();
            base.Initialize(this.transportProxy);
        }

        private void Init()
        {
            if (true == this.adapterRegistered)
                return;

            Trace.WriteLine(string.Format("GrabCasterAdapter.Init called"),"GrabCasterReceive: Info" );

            lock(this)
            {
                if (false == this.adapterRegistered)
                {

                }
            }
        }

        private void Term()
        {
            if (false == this.adapterRegistered)
                return;

            lock(this)
            {
                if (true == this.adapterRegistered)
                {
                    this.terminator.Terminate();

                    // Inform this adapter's Transport Proxy that this
                    // Adapter is shutting down...
                    this.transportProxy.TerminateIsolatedReceiver();
                }
            }
        }

        // Request processing method...
        public void ProcessRequest(MessageContract context)
        {
            this.Init();

            Trace.WriteLine(string.Format("HttpReceiveAdapter.ProcessRequest called"),"HttpReceive: Info" );

            // Create a new message...
            IBaseMessage msg = this.ConstructMessage(context);

            // Submit the message using the StandardReceiveBatchHandler
            SyncReceiveSubmitBatch batch = new SyncReceiveSubmitBatch(this.transportProxy, this.terminator, 1);

            // Do one-way-submit
            batch.SubmitMessage(msg, null);
            batch.Done();

            if ( !batch.Wait() )
            {
                Trace.WriteLine("GrabCasterAdapter.ProcessRequest(): Failed to process the Request!", "GrabCasterReceiveHandler: Error");
                throw new HttpException(400, "Failed to process the GrabCaster Point Request");
            }

        }

        IBaseMessage ConstructMessage(MessageContract context)
        {
            // Create a new message...
            IBaseMessage msg = this.msgFactory.CreateMessage();
            IBaseMessagePart body = this.msgFactory.CreateMessagePart();
            msg.AddPart("Body", body, true);

            // Attach the request stream to the message body part...
            Stream stream = new MemoryStream(context.body);
            if (!stream.CanSeek)
            {
                // The stream must be seekable for property error handling!
                stream = new VirtualStream(stream);
            }
            msg.BodyPart.Data = stream;

            // Determine the charset and content type and stamp on the message context...
            body.ContentType = context.GetType().ToString();
            body.Charset = "";

            // Properties on the msg ctx...
            //msg.Context.Write(WindowsUserProperty.Name.Name, WindowsUserProperty.Name.Namespace, user);
            // Promote properties
            //msg.Context.Promote(InboundTransportLocationProperty.Name.Name, InboundTransportLocationProperty.Name.Namespace, uri );

            //// If Loopback is configured, stamp it on the message context...
            //if (ep.Configuration.LoopBack && ep.Configuration.PortIsTwoWay)
            //{
            //    msg.Context.Write(LoopBackProperty.Name.Name, LoopBackProperty.Name.Namespace, true);
            //}

            return msg;
        }
    }
}

